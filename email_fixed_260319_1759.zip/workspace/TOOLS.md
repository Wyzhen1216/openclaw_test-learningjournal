# TOOLS.md - Local Notes

Skills define _how_ tools work. This file is for _your_ specifics — the stuff that's unique to your setup.

## What Goes Here

Things like:

- Camera names and locations
- SSH hosts and aliases
- Preferred voices for TTS
- Speaker/room names
- Device nicknames
- Anything environment-specific

## Examples

```markdown
### Cameras

- living-room → Main area, 180° wide angle
- front-door → Entrance, motion-triggered

### SSH

- home-server → 192.168.1.100, user: admin

### TTS

- Preferred voice: "Nova" (warm, slightly British)
- Default speaker: Kitchen HomePod
```

## Why Separate?

Skills are shared. Your setup is yours. Keeping them apart means you can update skills without losing your notes, and share skills without leaking your infrastructure.

### Email

- **Skill location:** `skills/email/`
- **Send script:** `skills/email/send-email.js`
- **Config file:** `skills/email/email-config.json`

**Configured Account:**
- **邮箱:** 3315850933@qq.com
- **SMTP:** smtp.qq.com:587

**Usage:**
```bash
node skills/email/send-email.js <to> <subject> <body> [from]
```

**Configuration options:**
1. Edit `skills/email/email-config.json`
2. Or set environment variables:
   - `EMAIL_SMTP_HOST` - SMTP server hostname
   - `EMAIL_SMTP_PORT` - SMTP server port (default: 587)
   - `EMAIL_SMTP_USER` - SMTP username
   - `EMAIL_SMTP_PASS` - SMTP password
   - `EMAIL_FROM` - Default from address

**Note:** Currently uses system `sendmail`/`mail` commands. SMTP support can be added with `nodemailer` if needed.

---

Add whatever helps you do your job. This is your cheat sheet.
